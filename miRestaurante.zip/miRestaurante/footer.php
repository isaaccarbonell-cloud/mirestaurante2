<footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Dime un restaurante</p>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>