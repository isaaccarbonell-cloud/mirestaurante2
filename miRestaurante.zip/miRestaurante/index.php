<?php get_header(); ?>

<div class="container" style="display: flex; max-width: 1200px; margin: 0 auto; font-family: sans-serif; gap: 30px; padding: 20px;">
    
    <aside style="width: 25%; padding: 20px; background: #f9f9f9; border-radius: 12px; align-self: flex-start;">
        <h2 style="font-size: 1.1rem; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px;">BUSCAR POR:</h2>
        <form method="get" action="<?php echo home_url('/'); ?>">
            
            <div style="margin-bottom: 25px;">
                <h4 style="font-size: 0.85rem; color: #666; margin-bottom: 10px;">UBICACIÓN</h4>
                <select name="ubicacion_filtro" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                    <option value="">Todas las ciudades</option>
                    <?php 
                    $ciudades = get_terms('ubicacion');
                    $ubi_sel = isset($_GET['ubicacion_filtro']) ? $_GET['ubicacion_filtro'] : '';
                    foreach($ciudades as $c) {
                        $selected = ($ubi_sel == $c->slug) ? 'selected' : '';
                        echo "<option value='{$c->slug}' {$selected}>{$c->name}</option>";
                    }
                    ?>
                </select>
            </div>

            <div style="margin-bottom: 25px;">
                <h4 style="font-size: 0.85rem; color: #666; margin-bottom: 10px;">COCINA</h4>
                <?php 
                $cocinas = get_terms('tipo_cocina');
                $cocinas_sel = isset($_GET['cocina']) ? (array)$_GET['cocina'] : array();
                foreach($cocinas as $c) : 
                    $checked = in_array($c->slug, $cocinas_sel) ? 'checked' : '';
                ?>
                    <label style="display: block; margin-bottom: 8px; font-size: 0.9rem; cursor: pointer;">
                        <input type="checkbox" name="cocina[]" value="<?php echo $c->slug; ?>" <?php echo $checked; ?>> 
                        <?php echo $c->name; ?>
                    </label>
                <?php endforeach; ?>
            </div>

            <div style="margin-bottom: 25px;">
                <h4 style="font-size: 0.85rem; color: #666; margin-bottom: 10px;">VALORACIÓN</h4>
                <select name="estrellas_filtro" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                    <?php $est_sel = isset($_GET['estrellas_filtro']) ? $_GET['estrellas_filtro'] : ''; ?>
                    <option value="" <?php selected($est_sel, ''); ?>>Cualquier puntuación</option>
                    <option value="5" <?php selected($est_sel, '5'); ?>>5 Estrellas</option>
                    <option value="4" <?php selected($est_sel, '4'); ?>>4 o más estrellas</option>
                    <option value="3" <?php selected($est_sel, '3'); ?>>3 o más estrellas</option>
                </select>
            </div>

            <button type="submit" style="width: 100%; padding: 12px; background: #000; color: #fff; border: none; cursor: pointer; font-weight: bold; border-radius: 5px;">
                APLICAR FILTROS
            </button>
            
            <?php if(!empty($_GET)): ?>
                <a href="<?php echo home_url('/'); ?>" style="display: block; text-align: center; margin-top: 15px; font-size: 0.8rem; color: #999; text-decoration: none;">✕ Limpiar filtros</a>
            <?php endif; ?>
        </form>
    </aside>

    <main style="width: 75%;">
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px;">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                
                <article style="background: #fff; border: 1px solid #eee; border-radius: 15px; overflow: hidden; text-align: center;">
                    <a href="<?php the_permalink(); ?>" style="text-decoration: none; color: inherit; display: block;">
                        
                        <?php if (has_post_thumbnail()) : ?>
                            <div style="height: 220px; background: #f5f5f5; overflow: hidden;">
                                <?php the_post_thumbnail('medium_large', array('style' => 'width:100%; height:100%; object-fit:cover;')); ?>
                            </div>
                        <?php else : ?>
                            <?php endif; ?>
                        
                        <div style="padding: 20px;">
                            <h3 style="margin: 0 0 10px 0; font-size: 1.2rem; text-transform: uppercase; letter-spacing: 1px; color: #000;">
                                <?php the_title(); ?>
                            </h3>
                            
                            <div style="color: #f1c40f; font-size: 1.3rem;">
                                <?php 
                                $stars = (int)get_post_meta(get_the_ID(), '_estrellas_restaurante', true);
                                echo $stars > 0 ? str_repeat('⭐', $stars) : '☆☆☆☆☆'; 
                                ?>
                            </div>
                        </div>
                    </a>
                </article>

            <?php endwhile; else : ?>
                <div style="grid-column: span 2; padding: 60px; text-align: center; color: #888;">
                    <p>No se encontraron restaurantes.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<?php get_footer(); ?>