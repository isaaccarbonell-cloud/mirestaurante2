<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header class="site-header">
    <div class="top-bar">
        <div class="container header-flex">
            <nav class="main-navigation">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'menu-principal',
                    'container'      => false,
                    'fallback_cb'    => false,
                ) );
                ?>
                <ul class="temp-menu">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Próximas visitas</a></li>
                    <li><a href="#">El Digestivo</a></li>
                    <li><a href="#">Más leídos</a></li>
                    <li><a href="#">Mapa</a></li>
                    <li><a href="#">CONTACTO</a></li>
                </ul>
            </nav>
        
        </div>
    </div>

    <div class="logo-bar">
        <div class="container text-center">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <img src="https://static.wikia.nocookie.net/map-games/images/c/cb/Imperio-bizantino.jpg/revision/latest?cb=20171020202555&path-prefix=es" alt="Alberto de Luna Logo" class="main-logo">
            </a>
        </div>
    </div>
</header>