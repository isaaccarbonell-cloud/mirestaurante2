<?php get_header(); ?>

<div class="container" style="max-width: 900px; margin: 40px auto; padding: 20px;">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        
        <article class="restaurante-detalle">
            <h1><?php the_title(); ?></h1>

            <div style="font-size: 24px; color: #f1c40f; margin-bottom: 20px;">
                <?php 
                $stars = (int)get_post_meta(get_the_ID(), '_estrellas_restaurante', true);
                echo str_repeat('⭐', $stars); 
                ?>
            </div>

            <div class="main-image" style="margin-bottom: 30px;">
                <?php if (has_post_thumbnail()) : ?>
                    <?php the_post_thumbnail('large', array('style' => 'width:100%; height:auto; border-radius:12px;')); ?>
                <?php endif; ?>
            </div>

            <div class="resumen-contenido" style="line-height: 1.8; font-size: 18px;">
                <?php the_content(); ?>
            </div>

            <hr style="margin: 40px 0;">
            <a href="<?php echo home_url('/'); ?>" style="text-decoration: none; color: #3498db;">← Volver al buscador</a>
        </article>

    <?php endwhile; endif; ?>
</div>

<?php get_footer(); ?>