<?php

function restaurante_setup_tema() {
    add_theme_support( 'post_thumbnails' );
    add_theme_support( 'title-tag' );
    register_nav_menus( array(
        'menu-principal' => 'Menú Cabecera Superior',
    ) );
}
add_action( 'after_setup_theme', 'restaurante_setup_tema' );

function restaurante_cargar_scripts() {
    wp_enqueue_style( 'dashicons' );
    wp_enqueue_style( 'main-styles', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'restaurante_cargar_scripts' );

function registrar_restaurantes_cpt() {
    register_post_type('restaurante', array(
        'public' => true,
        'label'  => 'Restaurantes',
        'menu_icon' => 'dashicons-rest-filter',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'has_archive' => true,
        'show_in_rest' => true,
    ));

    register_taxonomy('ubicacion', 'restaurante', array(
        'label' => 'Ubicaciones',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    register_taxonomy('tipo_cocina', 'restaurante', array(
        'label' => 'Tipos de Cocina',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
}
add_action('init', 'registrar_restaurantes_cpt');


function motor_busqueda_restaurantes( $query ) {
    if ( !is_admin() && $query->is_main_query() && $query->is_home() ) {
        
        $query->set( 'post_type', 'restaurante' );


        $tax_query = array('relation' => 'AND');

        if ( !empty($_GET['ubicacion_filtro']) ) {
            $tax_query[] = array(
                'taxonomy' => 'ubicacion',
                'field'    => 'slug',
                'terms'    => $_GET['ubicacion_filtro'],
            );
        }

        if ( !empty($_GET['cocina']) ) {
            $tax_query[] = array(
                'taxonomy' => 'tipo_cocina',
                'field'    => 'slug',
                'terms'    => (array)$_GET['cocina'],
                'operator' => 'IN',
            );
        }

        if ( count($tax_query) > 1 ) {
            $query->set( 'tax_query', $tax_query );
        }


        if ( !empty($_GET['estrellas_filtro']) ) {
            $query->set('meta_query', array(
                array(
                    'key'     => '_estrellas_restaurante',
                    'value'   => $_GET['estrellas_filtro'],
                    'compare' => '>=',
                    'type'    => 'NUMERIC'
                )
            ));
        }
    }
}
add_action( 'pre_get_posts', 'motor_busqueda_restaurantes' );

add_action('add_meta_boxes', function() {
    add_meta_box('estrellas_id', 'Clasificación', 'html_meta_box_estrellas', 'restaurante', 'side');
});

function html_meta_box_estrellas($post) {
    $valor = get_post_meta($post->ID, '_estrellas_restaurante', true);
    echo '<input type="number" name="estrellas_field" value="'.esc_attr($valor).'" min="1" max="5" style="width:100%">';
}

add_action('save_post', function($post_id) {
    if (isset($_POST['estrellas_field'])) {
        update_post_meta($post_id, '_estrellas_restaurante', $_POST['estrellas_field']);
    }
});