<?php
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$estrellas_filtro = isset($_GET['estrellas']) ? $_GET['estrellas'] : '';

$args = array(
    'post_type'      => 'restaurante',
    'posts_per_page' => 20,
    'paged'          => $paged,
    'meta_query'     => array(),
);


if ( !empty($estrellas_filtro) ) {
    $args['meta_query'][] = array(
        'key'     => '_estrellas_restaurante',
        'value'   => $estrellas_filtro,
        'compare' => '='
    );
}

$query_restaurantes = new WP_Query($args);